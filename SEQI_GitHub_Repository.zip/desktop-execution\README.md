# SEQI Windows Application Guide

This folder contains the complete desktop execution suite for running the **SEQI (School Evaluation & Quality Improvement)** application locally on any Windows PC as a standalone desktop application.

---

## Standalone Windows Application (`SEQI.exe`)

You can launch SEQI in two easy ways:

### Method 1: Direct Double-Click (Recommended)
1. Double-click **`SEQI.exe`** in the application folder (`I:\SEQI_Final\SEQI.exe`).
2. The application will:
   - Start the background server silently (no black command prompt window).
   - Open a dedicated, frameless desktop application window.
   - Automatically clean up the server when you close the window.

### Method 2: Windows Desktop Shortcut
1. Double-click **`CREATE_DESKTOP_SHORTCUT.bat`**.
2. A **"SEQI - School Quality System"** shortcut with the official gold icon will be placed directly on your Windows Desktop.
3. Double-click the shortcut on your desktop whenever you want to use the app.

---

## Log In Credentials

- **URL:** `http://localhost:3000`
- **Default Username:** `admin`
- **Default Password:** `admin123` *(configured in `.env`)*

---

## Utilities in this Folder

| File | Purpose |
| :--- | :--- |
| **`SEQI.exe`** | **Primary Desktop Application**: Native Windows launcher running in dedicated window mode. |
| **`CREATE_DESKTOP_SHORTCUT.bat`** | Creates a **"SEQI - School Quality System"** shortcut on your Windows Desktop. |
| **`desktop-execution\START_SEQI.bat`** | Alternative console-based launcher with detailed status logs. |
| **`desktop-execution\STOP_SEQI.bat`** | Safely stops any running SEQI process on port 3000. |

---

## Local Data & Backups

All school audit data, evaluations, and photos are stored locally on this machine:
- **Database:** `database.db` (SQLite file containing all scores, indicators, faculty, and users)
- **Uploaded Photos & Evidence:** `uploads/` folder

> **Backup Tip:** To back up your school's data, simply copy `database.db` and the `uploads/` folder to a secure USB drive or external drive.
