@echo off
title SEQI - First-time Setup and Build

cd /d "%~dp0.."

echo =====================================================================
echo           SEQI System Setup & Production Build
echo =====================================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is required but was not found.
    echo Please install Node.js (18+) from https://nodejs.org
    pause
    exit /b 1
)

echo [*] Installing NPM dependencies...
call npm install
if %errorlevel% neq 0 (
    echo [ERROR] npm install encountered errors.
    pause
    exit /b 1
)

echo.
echo [*] Building Frontend (Vite) and Backend (TypeScript)...
call npm run build
if %errorlevel% neq 0 (
    echo [ERROR] Build failed.
    pause
    exit /b 1
)

echo.
echo =====================================================================
echo [*] Setup and build completed successfully!
echo [*] You can now run START_SEQI.bat to start the system.
echo =====================================================================
pause
