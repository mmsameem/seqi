@echo off
setlocal enabledelayedexpansion
title SEQI - School Evaluation & Quality Improvement System

:: Determine if running inside desktop-execution folder or standalone
if exist "%~dp0..\server.js" (
    set "ROOT_DIR=%~dp0.."
) else (
    set "ROOT_DIR=%~dp0"
)

cd /d "%ROOT_DIR%"

echo =====================================================================
echo        SEQI - Institutional Quality Assurance System
echo =====================================================================
echo.

:: 1. Check for Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js was not found on this computer.
    echo.
    echo Please install Node.js (version 18 or newer) from:
    echo https://nodejs.org
    echo.
    echo After installing Node.js, run this script again.
    echo =====================================================================
    pause
    exit /b 1
)

:: Show Node.js version
for /f "tokens=*" %%v in ('node -v') do set "NODE_VER=%%v"
echo [*] Node.js version: %NODE_VER%

:: 2. Check for .env file
if not exist ".env" (
    echo [*] Creating .env configuration file from template...
    if exist ".env.example" (
        copy /y ".env.example" ".env" >nul
    ) else (
        (
            echo NODE_ENV=production
            echo PORT=3000
            echo JWT_SECRET=seqi-local-desktop-token-secret-%RANDOM%%RANDOM%
            echo DATABASE_PATH=database.db
            echo UPLOAD_DIR=uploads
            echo DEFAULT_ADMIN_USERNAME=admin
            echo DEFAULT_ADMIN_PASSWORD=admin123
        ) > ".env"
    )
    echo [*] .env configuration initialized.
)

:: 3. Check for node_modules
if not exist "node_modules\" (
    echo [*] Dependencies not found. Installing packages (this may take a few minutes)...
    call npm install
    if %errorlevel% neq 0 (
        echo [ERROR] npm install failed. Please check your internet connection and try again.
        pause
        exit /b 1
    )
)

:: 4. Check for production build artifacts (dist and dist-server)
if not exist "dist\" (
    set "NEED_BUILD=1"
)
if not exist "dist-server\" (
    set "NEED_BUILD=1"
)

if defined NEED_BUILD (
    echo [*] Building application frontend and backend...
    call npm run build
    if %errorlevel% neq 0 (
        echo [ERROR] Build failed. Please check the logs above.
        pause
        exit /b 1
    )
    echo [*] Build completed successfully.
)

:: 5. Start the SEQI Server
echo.
echo =====================================================================
echo [*] Starting SEQI server on http://localhost:3000 ...
echo [*] Default Login:
echo       Username: admin
echo       Password: (set in .env, default: admin123)
echo =====================================================================
echo.
echo Press Ctrl+C in this window to stop the server at any time.
echo.

:: Launch browser in background after 2 seconds
start /b cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:3000"

:: Run the server
if exist "server.js" (
    node server.js
) else (
    npm start
)

pause
