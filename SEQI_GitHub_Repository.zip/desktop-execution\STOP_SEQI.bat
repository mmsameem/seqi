@echo off
title Stop SEQI Server

echo =====================================================================
echo                    Stopping SEQI Server
echo =====================================================================
echo.

set "FOUND=0"
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :3000 ^| findstr LISTENING') do (
    echo [*] Found SEQI process running on Port 3000 (PID: %%a)
    taskkill /PID %%a /F >nul 2>nul
    set "FOUND=1"
)

if "!FOUND!"=="1" (
    echo [*] SEQI server stopped successfully.
) else (
    echo [*] No SEQI server process was running on Port 3000.
)

echo.
echo =====================================================================
timeout /t 3 >nul
